pysam coordinates are wrong
===========================

pysam uses 0-based coordinates and the half-open notation for ranges
as does python. Coordinates and intervals reported from pysam always
follow that convention.

Confusion might arise as different file formats might have different
conventions. For example, the SAM format is 1-based while the BAM
format is 0-based. It is important to remember that pysam will always
conform to the python convention and translate to/from the file format
automatically.

The only exception is the :term:`region string` in the :meth:`Samfile.fetch`
and :meth:`Samfile.pileup` methods. This string follows the convention
of the samtools command line utilities. The same is true for any
coordinates passed to the samtools command utilities directly, such
as :meth:`pysam.mpileup`.

BAM files with a large number of reference sequences is slow
============================================================

If you have many reference sequences in a bam file, the following
might be slow::

      track = pysam.Samfile(fname, "rb")
      for aln in track.fetch():
      	  pass
	  
The reason is that track.fetch() will iterate through the bam file
for each reference sequence in the order as it is defined in the
header. This might require a lot of jumping around in the file. To
avoid this, use::

      track = pysam.Samfile(fname, "rb")
      for aln in track.fetch( until_eof = True ):
      	  pass
 
This will iterate through reads as they appear in the file.

